<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc_Markdown extends Kohana_Kodoc_Markdown {}
