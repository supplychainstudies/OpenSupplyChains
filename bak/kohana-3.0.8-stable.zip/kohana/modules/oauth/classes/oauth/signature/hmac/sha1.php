<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Signature_HMAC_SHA1 extends Kohana_OAuth_Signature_HMAC_SHA1 {  }
