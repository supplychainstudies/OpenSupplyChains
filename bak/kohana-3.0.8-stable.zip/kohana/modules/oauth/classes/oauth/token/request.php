<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Token_Request extends Kohana_OAuth_Token_Request {  }
