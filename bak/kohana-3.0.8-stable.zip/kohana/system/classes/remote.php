<?php defined('SYSPATH') or die('No direct script access.');

class Remote extends Kohana_Remote {}
