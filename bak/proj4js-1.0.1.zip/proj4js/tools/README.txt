This directory contains tools used in the packaging or deployment of proj4js.

Javascript minimizing tools:

 * jsmin.c, jsmin.py:
   jsmin.py is a direct translation of the jsmin.c code into Python. jsmin.py
   will therefore run anyplace Python runs... but at significantly slower speed.
