<?php defined('SYSPATH') or die('No direct script access.');

class UTF8 extends Kohana_UTF8 {}
