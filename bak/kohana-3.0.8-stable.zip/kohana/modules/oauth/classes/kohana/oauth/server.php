<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * OAuth Server
 *
 * @package    Kohana/OAuth
 * @category   Server
 * @author     Kohana Team
 * @copyright  (c) 2010 Kohana Team
 * @license    http://kohanaframework.org/license
 * @since      3.0.7
 */
abstract class Kohana_OAuth_Server {

} // End OAuth_Server
