<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Provider_Twitter extends Kohana_OAuth_Provider_Twitter {  }
