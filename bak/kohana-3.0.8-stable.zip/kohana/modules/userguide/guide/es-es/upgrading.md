# Actualizando

Obviamente te gustaría actualizar tu código desde la versión 2 a la 3, y para hacer esta transición más fácil hemos recopilado algunos de los principales cambios desde la versión 

* [Kohana 2.3](upgrading.23)
