<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Xcache extends Kohana_Cache_Xcache {}